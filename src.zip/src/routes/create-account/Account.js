import React from "react";
import "./Account.css";
import { AiFillCaretRight } from "react-icons/ai";

function Account() {
  return (
    <div>
      <div className="account">
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/2560px-Amazon_logo.svg.png"
          alt=""
        />
        <form>
          <div className="create_account">
            <h1>Create Account</h1>
            <h5>Email or mobile phone number</h5>
            <input type="email" />
            <h5>Mobile number or Email</h5>
            <input type="email" />
            <h5>Password</h5>
            <input
              type="password"
              maxLength="6"
              placeholder="At least 6 characters"
            />
            <p className="password_notice">
              Passwords must be at least 6 characters.
            </p>
            <h5>Re-enter password</h5>
            <input type="password" />
            <button>Continue</button>
            <p>
              By creating an account, you agree to Amazon's Conditions of Use
              and Privacy Notice.
            </p>
            <div className="create_bottom">
              <p>
                Already have an account?{" "}
                <a href="##">
                  Sign-In <AiFillCaretRight />
                </a>
              </p>
              <p>
                Buying for work?{" "}
                <a href="##">
                  Create a free business account <AiFillCaretRight />
                </a>
              </p>
            </div>
          </div>
        </form>
        <div className="account_copyright">
          <div className="account_help">
            <a href="##">Conditin of Use</a>
            <a href="##">Privacy Notice</a>
            <a href="##">Help</a>
          </div>
          <p>© 1996-2022, Amazon.com, Inc. or its affiliates</p>
        </div>
      </div>
    </div>
  );
}

export default Account;
