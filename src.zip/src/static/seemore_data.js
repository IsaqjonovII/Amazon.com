export const seemore_data = [
    {
        id: 0,
        imageURL: "https://media.gamestop.com/i/gamestop/10141820/Nintendo-Switch-Console-Gray-Joy-Con?$pdp$",
        productName: "Nintendo",
        link: "/products"
    },
    {
        id: 1,
        imageURL: "https://media.ldlc.com/r1600/ld/products/00/05/72/19/LD0005721972_1_0005722030_0005874020.jpg",
        productName: "Oculus",
        link: "/products"
    },
    {
        id: 2,
        imageURL: "https://www.ubuy.uz/productimg/?image=aHR0cHM6Ly9tLm1lZGlhLWFtYXpvbi5jb20vaW1hZ2VzL0kvNzFOQlEyYTUyQ0wuX1NMMTUwMF8uanBn.jpg",
        productName: "XBOX",
        link: "/products"
    },
    {
        id: 3,
        imageURL: "https://p.globalsources.com/IMAGES/PDT/B1185383367/wired-game-controllers-pc.jpg",
        productName: "Laptops",
        link: "/products"
    },
    {
        id: 4,
        imageURL: "https://www.reliancedigital.in/medias/Microsoft-Surface-Laptop-Go-Laptops-491946834-i-1-1200Wx1200H?context=bWFzdGVyfGltYWdlc3wyMjIzMjJ8aW1hZ2UvanBlZ3xpbWFnZXMvaGVjL2gwNi85NDY2MzQ1Njg1MDIyLmpwZ3wwMGVjMzE3MTc3MjY4MjAyODQ5ZDBlYjkyNDcyOWZjYTBiNzY2ODhmNjFjNjAzN2I2OWQxY2JjMGZmODEzNmMw",
        productName: "Controllers",
        link: "/products"
    },
    {
        id: 5,
        imageURL: "https://cdn2.from.ae/media/catalog/product/cache/image/9df78eab33525d08d6e5fb8d27136e95/0/1/01_117_176_1.jpg",
        productName: "Plastation",
        link: "/products"
    },
    {
        id: 6,
        imageURL: "https://images-na.ssl-images-amazon.com/images/G/01/AmazonExports/Karu/2021/June/Karu_LP_Game.png",
        productName: "Video Games",
        link: "/products"
    },
    {
        id: 7,
        imageURL: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZhmOMlCs-AgQss2M2ImNzOQ5KNPk6Q5wwVMJhrNtRsDk810xmjYHPUOHfIIkombyfXIo&usqp=CAU",
        productName: "Headests",
        link: "/products"
    },
    {
        id: 8,
        imageURL: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYzc60pVNpX7jYp6csfqjsnsxnj316zZji3qcOdyct9-C70sTnde2_BOihAezQa8scCzE&usqp=CAU",
        productName: "Keyboards",
        link: "/products"
    },
    {
        id: 9,
        imageURL: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7yxLp5UfMtFUnYORrW3HIBzvxxT5Ii6pNYg&usqp=CAU",
        productName: "Chairs",
        link: "/products"
    },
    {
        id: 10,
        imageURL: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkewVoTqwlQBM9RNcYelAUoZrbVhC3TEBq6e38AC7--Zi7Yphco4d3mXahqh2qz4jfl8Y&usqp=CAU",
        productName: "Gaming mice",
        link: "/products"
    },
    {
        id: 11,
        imageURL: "https://cdn.shopify.com/s/files/1/0801/0325/products/Texas_Tshirts_Paris_Texas_Apparel_Co_Texas_Charge_Pocket_Tshirt_Unisex_White_1_1024x1024.jpg?v=1598638733",
        productName: "Apparel",
        link: "/products"
    },
    {
        id: 12,
        imageURL: "https://c1-ebgames.eb-cdn.com.au/merchandising/images/packshots/e0ac67d423a749c48a43a178d4e0fdae_Large.jpg",
        productName: "Action Figures",
        link: "/products"
    },
    {
        id: 13,
        imageURL: "https://i5.walmartimages.com/asr/f2f87081-3d26-4c3e-9c39-ae48a45169b0.bd1f93a2f9f6c0660259da90143ef8c8.jpeg",
        productName: "Hats",
        link: "/products"
    },
    {
        id: 14,
        imageURL: "https://images.lookhuman.com/render/standard/2Iij3pK0X4kjFnxnACvDakQ2dCfcnT1I/mug15oz-whi-z1-t-black-and-white-plant-pattern.jpg",
        productName: "Mugs",
        link: "/products"
    }
]