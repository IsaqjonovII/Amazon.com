export const shopnow_data = [
    {
        id: 1,
        imageUrl: "https://m.media-amazon.com/images/I/7120GgUKj3L._AC_UL320_.jpg",
        productName: "Apple AirPods (2nd Generation)"
    }
]